package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class c1f2 extends AppCompatActivity {

    private ImageView img1;
    private ImageView img2;
    private ImageView img3;
    private ImageView img4;
    private ImageView img5;
    private ImageView img6;
    private ImageView img7;
    private ImageView img8;
    private ImageView img9;
    private ImageView img10;
    private ImageView img11;
    private ImageView img12;
    private ImageView img121;
    private ImageView img13;
    private ImageView img14;
    private ImageView img15;
    private ImageView img16;
    private ImageView img17;
    private ImageView img18;
    private ImageView img19;
    private ImageView img20;
    private ImageView img21;
    private ImageView img22;
    private ImageView img23;
    private ImageView img24;
    private ImageView img25;
    private ImageView img26;
    private ImageView img27;
    private ImageView img28;
    private ImageView img29;
    private ImageView img30;
    private ImageView img31;
    private ImageView img32;
    private ImageView img33;
    private ImageView img34;
    private ImageView img35;
    private ImageView img36;
    private ImageView img37;
    private ImageView img38;
    private ImageView img39;
    private Button btn;
    private EditText num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c1f2);
        office();
    }
    public void office(){
        img1 = (ImageView)findViewById(R.id.imageView13);
        img2 = (ImageView)findViewById(R.id.imageView12);
        img3 = (ImageView)findViewById(R.id.imageView14);
        img4 = (ImageView)findViewById(R.id.imageView15);
        img5 = (ImageView)findViewById(R.id.imageView16);
        img6 = (ImageView)findViewById(R.id.imageView17);
        img7 = (ImageView)findViewById(R.id.imageView18);
        img8 = (ImageView)findViewById(R.id.imageView19);
        img9 = (ImageView)findViewById(R.id.imageView20);
        img10 = (ImageView)findViewById(R.id.imageView21);
        img11 = (ImageView)findViewById(R.id.imageView22);
        img12 = (ImageView)findViewById(R.id.imageView23);
        img121 = (ImageView)findViewById(R.id.imageView24);
        img13 = (ImageView)findViewById(R.id.imageView25);
        img14 = (ImageView)findViewById(R.id.imageView26);
        img15 = (ImageView)findViewById(R.id.imageView27);
        img16 = (ImageView)findViewById(R.id.imageView28);
        img17 = (ImageView)findViewById(R.id.imageView30);
        img18 = (ImageView)findViewById(R.id.imageView31);
        img19 = (ImageView)findViewById(R.id.imageView32);
        img20 = (ImageView)findViewById(R.id.imageView33);
        img21 = (ImageView)findViewById(R.id.imageView34);
        img22 = (ImageView)findViewById(R.id.imageView35);
        img23 = (ImageView)findViewById(R.id.imageView36);
        img24 = (ImageView)findViewById(R.id.imageView37);
        img25 = (ImageView)findViewById(R.id.imageView38);
        img26 = (ImageView)findViewById(R.id.imageView39);
        img27 = (ImageView)findViewById(R.id.imageView40);
        img28 = (ImageView)findViewById(R.id.imageView41);
        img29 = (ImageView)findViewById(R.id.imageView42);
        img30 = (ImageView)findViewById(R.id.imageView29);
        img31 = (ImageView)findViewById(R.id.imageView43);
        img32 = (ImageView)findViewById(R.id.imageView44);
        img33 = (ImageView)findViewById(R.id.imageView45);
        img34 = (ImageView)findViewById(R.id.imageView46);
        img35 = (ImageView)findViewById(R.id.imageView47);
        img36 = (ImageView)findViewById(R.id.imageView48);
        img37 = (ImageView)findViewById(R.id.imageView49);
        img38 = (ImageView)findViewById(R.id.imageView50);
        img39 = (ImageView)findViewById(R.id.imageView51);
        btn = (Button)findViewById(R.id.button15);
        num = (EditText)findViewById(R.id.editTextNumber3);

        btn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String a1 = "221";
                        String a2 = "222";
                        String a3 = "223";
                        String a4 = "224";
                        String a5 = "226";
                        String a6 = "227";
                        String a7 = "228";
                        String a8 = "231";
                        String a9 = "232";
                        String a10 = "233";
                        String a11 = "234";
                        String a12 = "235";
                        String a13 = "238";
                        String a14 = "239";
                        String a15 = "240";
                        String a16 = "241";
                        String a17 = "242";
                        String a18 = "244";
                        String a19 = "248";
                        String a20 = "250";
                        String a21 = "251";
                        String a22 = "252";
                        String a23 = "253";
                        String a24 = "254";
                        String a25 = "255";
                        String a26 = "256";
                        String a27 = "260";
                        String a28 = "261";
                        String a29 = "262";
                        String a30 = "263";
                        String a31 = "264";
                        String a32 = "265";
                        String a33 = "266";
                        String a34 = "267";
                        String a35 = "268";
                        String a36 = "269";
                        String a37 = "270";
                        String a38 = "271";
                        String a39 = "272";
                        String a40 = "273";
                        if (a1.equals(String.valueOf(num.getText())))
                            img1.setVisibility(View.VISIBLE);
                        else
                            img1.setVisibility(View.INVISIBLE);
                        if (a2.equals(String.valueOf(num.getText())))
                            img2.setVisibility(View.VISIBLE);
                        else
                            img2.setVisibility(View.INVISIBLE);
                        if (a3.equals(String.valueOf(num.getText())))
                            img3.setVisibility(View.VISIBLE);
                        else
                            img3.setVisibility(View.INVISIBLE);
                        if (a4.equals(String.valueOf(num.getText())))
                            img4.setVisibility(View.VISIBLE);
                        else
                            img4.setVisibility(View.INVISIBLE);
                        if (a5.equals(String.valueOf(num.getText())))
                            img5.setVisibility(View.VISIBLE);
                        else
                            img5.setVisibility(View.INVISIBLE);
                        if (a6.equals(String.valueOf(num.getText())))
                            img6.setVisibility(View.VISIBLE);
                        else
                            img6.setVisibility(View.INVISIBLE);
                        if (a7.equals(String.valueOf(num.getText())))
                            img7.setVisibility(View.VISIBLE);
                        else
                            img7.setVisibility(View.INVISIBLE);
                        if (a8.equals(String.valueOf(num.getText())))
                            img8.setVisibility(View.VISIBLE);
                        else
                            img8.setVisibility(View.INVISIBLE);
                        if (a9.equals(String.valueOf(num.getText())))
                            img9.setVisibility(View.VISIBLE);
                        else
                            img9.setVisibility(View.INVISIBLE);
                        if (a10.equals(String.valueOf(num.getText())))
                            img10.setVisibility(View.VISIBLE);
                        else
                            img10.setVisibility(View.INVISIBLE);
                        if (a11.equals(String.valueOf(num.getText())))
                            img11.setVisibility(View.VISIBLE);
                        else
                            img11.setVisibility(View.INVISIBLE);
                        if (a12.equals(String.valueOf(num.getText())))
                            img12.setVisibility(View.VISIBLE);
                        else
                            img12.setVisibility(View.INVISIBLE);
                        if (a13.equals(String.valueOf(num.getText())))
                            img121.setVisibility(View.VISIBLE);
                        else
                            img121.setVisibility(View.INVISIBLE);
                        if (a14.equals(String.valueOf(num.getText())))
                            img13.setVisibility(View.VISIBLE);
                        else
                            img13.setVisibility(View.INVISIBLE);
                        if (a15.equals(String.valueOf(num.getText())))
                            img14.setVisibility(View.VISIBLE);
                        else
                            img14.setVisibility(View.INVISIBLE);
                        if (a16.equals(String.valueOf(num.getText())))
                            img15.setVisibility(View.VISIBLE);
                        else
                            img15.setVisibility(View.INVISIBLE);
                        if (a17.equals(String.valueOf(num.getText())))
                            img16.setVisibility(View.VISIBLE);
                        else
                            img16.setVisibility(View.INVISIBLE);
                        if (a18.equals(String.valueOf(num.getText())))
                            img30.setVisibility(View.VISIBLE);
                        else
                            img30.setVisibility(View.INVISIBLE);
                        if (a19.equals(String.valueOf(num.getText())))
                            img17.setVisibility(View.VISIBLE);
                        else
                            img17.setVisibility(View.INVISIBLE);
                        if (a20.equals(String.valueOf(num.getText())))
                            img18.setVisibility(View.VISIBLE);
                        else
                            img18.setVisibility(View.INVISIBLE);
                        if (a21.equals(String.valueOf(num.getText())))
                            img19.setVisibility(View.VISIBLE);
                        else
                            img19.setVisibility(View.INVISIBLE);
                        if (a22.equals(String.valueOf(num.getText())))
                            img20.setVisibility(View.VISIBLE);
                        else
                            img20.setVisibility(View.INVISIBLE);
                        if (a23.equals(String.valueOf(num.getText())))
                            img21.setVisibility(View.VISIBLE);
                        else
                            img21.setVisibility(View.INVISIBLE);
                        if (a24.equals(String.valueOf(num.getText())))
                            img22.setVisibility(View.VISIBLE);
                        else
                            img22.setVisibility(View.INVISIBLE);
                        if (a25.equals(String.valueOf(num.getText())))
                            img23.setVisibility(View.VISIBLE);
                        else
                            img23.setVisibility(View.INVISIBLE);
                        if (a26.equals(String.valueOf(num.getText())))
                            img24.setVisibility(View.VISIBLE);
                        else
                            img24.setVisibility(View.INVISIBLE);
                        if (a27.equals(String.valueOf(num.getText())))
                            img25.setVisibility(View.VISIBLE);
                        else
                            img25.setVisibility(View.INVISIBLE);
                        if (a28.equals(String.valueOf(num.getText())))
                            img26.setVisibility(View.VISIBLE);
                        else
                            img26.setVisibility(View.INVISIBLE);
                        if (a29.equals(String.valueOf(num.getText())))
                            img27.setVisibility(View.VISIBLE);
                        else
                            img27.setVisibility(View.INVISIBLE);
                        if (a30.equals(String.valueOf(num.getText())))
                            img28.setVisibility(View.VISIBLE);
                        else
                            img28.setVisibility(View.INVISIBLE);
                        if (a31.equals(String.valueOf(num.getText())))
                            img29.setVisibility(View.VISIBLE);
                        else
                            img29.setVisibility(View.INVISIBLE);
                        if (a32.equals(String.valueOf(num.getText())))
                            img31.setVisibility(View.VISIBLE);
                        else
                            img31.setVisibility(View.INVISIBLE);
                        if (a33.equals(String.valueOf(num.getText())))
                            img32.setVisibility(View.VISIBLE);
                        else
                            img32.setVisibility(View.INVISIBLE);
                        if (a34.equals(String.valueOf(num.getText())))
                            img33.setVisibility(View.VISIBLE);
                        else
                            img33.setVisibility(View.INVISIBLE);
                        if (a35.equals(String.valueOf(num.getText())))
                            img34.setVisibility(View.VISIBLE);
                        else
                            img34.setVisibility(View.INVISIBLE);
                        if (a36.equals(String.valueOf(num.getText())))
                            img35.setVisibility(View.VISIBLE);
                        else
                            img35.setVisibility(View.INVISIBLE);
                        if (a37.equals(String.valueOf(num.getText())))
                            img36.setVisibility(View.VISIBLE);
                        else
                            img36.setVisibility(View.INVISIBLE);
                        if (a38.equals(String.valueOf(num.getText())))
                            img37.setVisibility(View.VISIBLE);
                        else
                            img37.setVisibility(View.INVISIBLE);
                        if (a39.equals(String.valueOf(num.getText())))
                            img38.setVisibility(View.VISIBLE);
                        else
                            img38.setVisibility(View.INVISIBLE);
                        if (a40.equals(String.valueOf(num.getText())))
                            img39.setVisibility(View.VISIBLE);
                        else
                            img39.setVisibility(View.INVISIBLE);
                    }
                }
        );
    }
}