package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class c3f2 extends AppCompatActivity {

    private ImageView img1;
    private ImageView img2;
    private ImageView img3;
    private ImageView img4;
    private ImageView img5;
    private ImageView img6;
    private ImageView img7;
    private ImageView img8;
    private ImageView img9;
    private ImageView img10;
    private ImageView img11;
    private ImageView img12;
    private ImageView img13;
    private ImageView img14;
    private ImageView img15;
    private ImageView img16;
    private ImageView img17;
    private ImageView img18;
    private ImageView img19;
    private ImageView img20;
    private ImageView img21;
    private ImageView img22;
    private ImageView img23;
    private ImageView img24;
    private ImageView img25;
    private ImageView img26;
    private ImageView img27;
    private ImageView img28;
    private ImageView img29;
    private ImageView img30;
    private ImageView img31;
    private ImageView img32;
    private ImageView img33;
    private ImageView img34;
    private ImageView img35;
    private ImageView img36;
    private ImageView img37;
    private ImageView img38;
    private ImageView img39;
    private ImageView img40;
    private ImageView img41;
    private Button btn;
    private EditText num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c3f2);
        office();
    }

    public void office(){
        img1 = (ImageView)findViewById(R.id.imageView13);
        img2 = (ImageView)findViewById(R.id.imageView52);
        img3 = (ImageView)findViewById(R.id.imageView53);
        img4 = (ImageView)findViewById(R.id.imageView54);
        img5 = (ImageView)findViewById(R.id.imageView55);
        img6 = (ImageView)findViewById(R.id.imageView56);
        img7 = (ImageView)findViewById(R.id.imageView57);
        img8 = (ImageView)findViewById(R.id.imageView58);
        img9 = (ImageView)findViewById(R.id.imageView59);
        img10 = (ImageView)findViewById(R.id.imageView60);
        img11 = (ImageView)findViewById(R.id.imageView61);
        img12 = (ImageView)findViewById(R.id.imageView62);
        img13 = (ImageView)findViewById(R.id.imageView63);
        img14 = (ImageView)findViewById(R.id.imageView64);
        img15 = (ImageView)findViewById(R.id.imageView65);
        img16 = (ImageView)findViewById(R.id.imageView66);
        img17 = (ImageView)findViewById(R.id.imageView67);
        img18 = (ImageView)findViewById(R.id.imageView68);
        img19 = (ImageView)findViewById(R.id.imageView69);
        img20 = (ImageView)findViewById(R.id.imageView70);
        img21 = (ImageView)findViewById(R.id.imageView71);
        img22 = (ImageView)findViewById(R.id.imageView72);
        img23 = (ImageView)findViewById(R.id.imageView73);
        img24 = (ImageView)findViewById(R.id.imageView74);
        img25 = (ImageView)findViewById(R.id.imageView75);
        img26 = (ImageView)findViewById(R.id.imageView76);
        img27 = (ImageView)findViewById(R.id.imageView77);
        img28 = (ImageView)findViewById(R.id.imageView78);
        img29 = (ImageView)findViewById(R.id.imageView79);
        img30 = (ImageView)findViewById(R.id.imageView80);
        img31 = (ImageView)findViewById(R.id.imageView81);
        img32 = (ImageView)findViewById(R.id.imageView82);
        img33 = (ImageView)findViewById(R.id.imageView83);
        img34 = (ImageView)findViewById(R.id.imageView84);
        img35 = (ImageView)findViewById(R.id.imageView85);
        img36 = (ImageView)findViewById(R.id.imageView86);
        img37 = (ImageView)findViewById(R.id.imageView87);
        img38 = (ImageView)findViewById(R.id.imageView88);
        img39 = (ImageView)findViewById(R.id.imageView89);
        img40 = (ImageView)findViewById(R.id.imageView90);
        img41 = (ImageView)findViewById(R.id.imageView91);
        btn = (Button)findViewById(R.id.button15);
        num = (EditText)findViewById(R.id.editTextNumber3);

        btn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String a1 = "221";
                        String a2 = "222";
                        String a3 = "223";
                        String a4 = "224";
                        String a5 = "225";
                        String a6 = "226";
                        String a7 = "227";
                        String a8 = "228";
                        String a9 = "229";
                        String a10 = "230";
                        String a11 = "231";
                        String a12 = "232";
                        String a13 = "233";
                        String a14 = "234";
                        String a15 = "235";
                        String a16 = "236";
                        String a17 = "237";
                        String a18 = "240";
                        String a19 = "241";
                        String a20 = "243";
                        String a21 = "244";
                        String a22 = "246";
                        String a23 = "247";
                        String a24 = "248";
                        String a25 = "249";
                        String a26 = "250";
                        String a27 = "251";
                        String a28 = "252";
                        String a29 = "253";
                        String a30 = "254";
                        String a31 = "255";
                        String a32 = "257";
                        String a33 = "258";
                        String a34 = "259";
                        String a35 = "260";
                        String a36 = "261";
                        String a37 = "262";
                        String a38 = "263";
                        String a39 = "264";
                        String a40 = "266";
                        String a41 = "267";
                        if (a1.equals(String.valueOf(num.getText())))
                            img1.setVisibility(View.VISIBLE);
                        else
                            img1.setVisibility(View.INVISIBLE);
                        if (a2.equals(String.valueOf(num.getText())))
                            img2.setVisibility(View.VISIBLE);
                        else
                            img2.setVisibility(View.INVISIBLE);
                        if (a3.equals(String.valueOf(num.getText())))
                            img3.setVisibility(View.VISIBLE);
                        else
                            img3.setVisibility(View.INVISIBLE);
                        if (a4.equals(String.valueOf(num.getText())))
                            img4.setVisibility(View.VISIBLE);
                        else
                            img4.setVisibility(View.INVISIBLE);
                        if (a5.equals(String.valueOf(num.getText())))
                            img5.setVisibility(View.VISIBLE);
                        else
                            img5.setVisibility(View.INVISIBLE);
                        if (a6.equals(String.valueOf(num.getText())))
                            img6.setVisibility(View.VISIBLE);
                        else
                            img6.setVisibility(View.INVISIBLE);
                        if (a7.equals(String.valueOf(num.getText())))
                            img7.setVisibility(View.VISIBLE);
                        else
                            img7.setVisibility(View.INVISIBLE);
                        if (a8.equals(String.valueOf(num.getText())))
                            img8.setVisibility(View.VISIBLE);
                        else
                            img8.setVisibility(View.INVISIBLE);
                        if (a9.equals(String.valueOf(num.getText())))
                            img9.setVisibility(View.VISIBLE);
                        else
                            img9.setVisibility(View.INVISIBLE);
                        if (a10.equals(String.valueOf(num.getText())))
                            img10.setVisibility(View.VISIBLE);
                        else
                            img10.setVisibility(View.INVISIBLE);
                        if (a11.equals(String.valueOf(num.getText())))
                            img11.setVisibility(View.VISIBLE);
                        else
                            img11.setVisibility(View.INVISIBLE);
                        if (a12.equals(String.valueOf(num.getText())))
                            img12.setVisibility(View.VISIBLE);
                        else
                            img12.setVisibility(View.INVISIBLE);
                        if (a13.equals(String.valueOf(num.getText())))
                            img13.setVisibility(View.VISIBLE);
                        else
                            img13.setVisibility(View.INVISIBLE);
                        if (a14.equals(String.valueOf(num.getText())))
                            img14.setVisibility(View.VISIBLE);
                        else
                            img14.setVisibility(View.INVISIBLE);
                        if (a15.equals(String.valueOf(num.getText())))
                            img15.setVisibility(View.VISIBLE);
                        else
                            img15.setVisibility(View.INVISIBLE);
                        if (a16.equals(String.valueOf(num.getText())))
                            img16.setVisibility(View.VISIBLE);
                        else
                            img16.setVisibility(View.INVISIBLE);
                        if (a17.equals(String.valueOf(num.getText())))
                            img17.setVisibility(View.VISIBLE);
                        else
                            img17.setVisibility(View.INVISIBLE);
                        if (a18.equals(String.valueOf(num.getText())))
                            img18.setVisibility(View.VISIBLE);
                        else
                            img18.setVisibility(View.INVISIBLE);
                        if (a19.equals(String.valueOf(num.getText())))
                            img19.setVisibility(View.VISIBLE);
                        else
                            img19.setVisibility(View.INVISIBLE);
                        if (a20.equals(String.valueOf(num.getText())))
                            img20.setVisibility(View.VISIBLE);
                        else
                            img20.setVisibility(View.INVISIBLE);
                        if (a21.equals(String.valueOf(num.getText())))
                            img21.setVisibility(View.VISIBLE);
                        else
                            img21.setVisibility(View.INVISIBLE);
                        if (a22.equals(String.valueOf(num.getText())))
                            img22.setVisibility(View.VISIBLE);
                        else
                            img22.setVisibility(View.INVISIBLE);
                        if (a23.equals(String.valueOf(num.getText())))
                            img23.setVisibility(View.VISIBLE);
                        else
                            img23.setVisibility(View.INVISIBLE);
                        if (a24.equals(String.valueOf(num.getText())))
                            img24.setVisibility(View.VISIBLE);
                        else
                            img24.setVisibility(View.INVISIBLE);
                        if (a25.equals(String.valueOf(num.getText())))
                            img25.setVisibility(View.VISIBLE);
                        else
                            img25.setVisibility(View.INVISIBLE);
                        if (a26.equals(String.valueOf(num.getText())))
                            img26.setVisibility(View.VISIBLE);
                        else
                            img26.setVisibility(View.INVISIBLE);
                        if (a27.equals(String.valueOf(num.getText())))
                            img27.setVisibility(View.VISIBLE);
                        else
                            img27.setVisibility(View.INVISIBLE);
                        if (a28.equals(String.valueOf(num.getText())))
                            img28.setVisibility(View.VISIBLE);
                        else
                            img28.setVisibility(View.INVISIBLE);
                        if (a29.equals(String.valueOf(num.getText())))
                            img29.setVisibility(View.VISIBLE);
                        else
                            img29.setVisibility(View.INVISIBLE);
                        if (a30.equals(String.valueOf(num.getText())))
                            img30.setVisibility(View.VISIBLE);
                        else
                            img30.setVisibility(View.INVISIBLE);
                        if (a31.equals(String.valueOf(num.getText())))
                            img31.setVisibility(View.VISIBLE);
                        else
                            img31.setVisibility(View.INVISIBLE);
                        if (a32.equals(String.valueOf(num.getText())))
                            img32.setVisibility(View.VISIBLE);
                        else
                            img32.setVisibility(View.INVISIBLE);
                        if (a33.equals(String.valueOf(num.getText())))
                            img33.setVisibility(View.VISIBLE);
                        else
                            img33.setVisibility(View.INVISIBLE);
                        if (a34.equals(String.valueOf(num.getText())))
                            img34.setVisibility(View.VISIBLE);
                        else
                            img34.setVisibility(View.INVISIBLE);
                        if (a35.equals(String.valueOf(num.getText())))
                            img35.setVisibility(View.VISIBLE);
                        else
                            img35.setVisibility(View.INVISIBLE);
                        if (a36.equals(String.valueOf(num.getText())))
                            img36.setVisibility(View.VISIBLE);
                        else
                            img36.setVisibility(View.INVISIBLE);
                        if (a37.equals(String.valueOf(num.getText())))
                            img37.setVisibility(View.VISIBLE);
                        else
                            img37.setVisibility(View.INVISIBLE);
                        if (a38.equals(String.valueOf(num.getText())))
                            img38.setVisibility(View.VISIBLE);
                        else
                            img38.setVisibility(View.INVISIBLE);
                        if (a39.equals(String.valueOf(num.getText())))
                            img39.setVisibility(View.VISIBLE);
                        else
                            img39.setVisibility(View.INVISIBLE);
                        if (a40.equals(String.valueOf(num.getText())))
                            img40.setVisibility(View.VISIBLE);
                        else
                            img40.setVisibility(View.INVISIBLE);
                        if (a41.equals(String.valueOf(num.getText())))
                            img41.setVisibility(View.VISIBLE);
                        else
                            img41.setVisibility(View.INVISIBLE);
                    }
                }
        );
    }
}