package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class c1f3 extends AppCompatActivity {

    private ImageView img1;
    private ImageView img2;
    private ImageView img3;
    private ImageView img4;
    private ImageView img5;
    private ImageView img6;
    private ImageView img7;
    private ImageView img8;
    private ImageView img9;
    private ImageView img10;
    private ImageView img11;
    private ImageView img12;
    private ImageView img13;
    private ImageView img14;
    private ImageView img15;
    private ImageView img16;
    private ImageView img17;
    private ImageView img18;
    private ImageView img19;
    private ImageView img20;
    private ImageView img21;
    private ImageView img22;
    private ImageView img23;
    private ImageView img24;
    private ImageView img25;
    private ImageView img26;
    private ImageView img27;
    private ImageView img28;
    private ImageView img29;
    private ImageView img30;
    private ImageView img31;
    private ImageView img32;
    private ImageView img33;
    private ImageView img34;
    private ImageView img35;
    private ImageView img36;
    private ImageView img37;
    private Button btn;
    private EditText num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c1f3);
        office();
    }

    public void office(){
        img1 = (ImageView)findViewById(R.id.imageView13);
        img2 = (ImageView)findViewById(R.id.imageView92);
        img3 = (ImageView)findViewById(R.id.imageView93);
        img4 = (ImageView)findViewById(R.id.imageView94);
        img5 = (ImageView)findViewById(R.id.imageView95);
        img6 = (ImageView)findViewById(R.id.imageView96);
        img7 = (ImageView)findViewById(R.id.imageView97);
        img8 = (ImageView)findViewById(R.id.imageView98);
        img9 = (ImageView)findViewById(R.id.imageView99);
        img10 = (ImageView)findViewById(R.id.imageView100);
        img11 = (ImageView)findViewById(R.id.imageView101);
        img12 = (ImageView)findViewById(R.id.imageView102);
        img13 = (ImageView)findViewById(R.id.imageView103);
        img14 = (ImageView)findViewById(R.id.imageView104);
        img15 = (ImageView)findViewById(R.id.imageView105);
        img16 = (ImageView)findViewById(R.id.imageView106);
        img17 = (ImageView)findViewById(R.id.imageView107);
        img18 = (ImageView)findViewById(R.id.imageView108);
        img19 = (ImageView)findViewById(R.id.imageView109);
        img20 = (ImageView)findViewById(R.id.imageView110);
        img21 = (ImageView)findViewById(R.id.imageView111);
        img22 = (ImageView)findViewById(R.id.imageView112);
        img23 = (ImageView)findViewById(R.id.imageView113);
        img24 = (ImageView)findViewById(R.id.imageView114);
        img25 = (ImageView)findViewById(R.id.imageView115);
        img26 = (ImageView)findViewById(R.id.imageView116);
        img27 = (ImageView)findViewById(R.id.imageView117);
        img28 = (ImageView)findViewById(R.id.imageView118);
        img29 = (ImageView)findViewById(R.id.imageView119);
        img30 = (ImageView)findViewById(R.id.imageView120);
        img31 = (ImageView)findViewById(R.id.imageView121);
        img32 = (ImageView)findViewById(R.id.imageView122);
        img33 = (ImageView)findViewById(R.id.imageView123);
        img34 = (ImageView)findViewById(R.id.imageView124);
        img35 = (ImageView)findViewById(R.id.imageView125);
        img36 = (ImageView)findViewById(R.id.imageView126);
        img37 = (ImageView)findViewById(R.id.imageView127);
        btn = (Button)findViewById(R.id.button15);
        num = (EditText)findViewById(R.id.editTextNumber3);

        btn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String a1 = "318";
                        String a2 = "320";
                        String a3 = "321";
                        String a4 = "322";
                        String a5 = "323";
                        String a6 = "324";
                        String a7 = "325";
                        String a8 = "326";
                        String a9 = "327";
                        String a10 = "328";
                        String a11 = "329";
                        String a12 = "330";
                        String a13 = "332";
                        String a14 = "333";
                        String a15 = "334";
                        String a16 = "335";
                        String a17 = "336";
                        String a18 = "337";
                        String a19 = "338";
                        String a20 = "341";
                        String a21 = "342";
                        String a22 = "343";
                        String a23 = "344";
                        String a24 = "346";
                        String a25 = "347";
                        String a26 = "348";
                        String a27 = "349";
                        String a28 = "350";
                        String a29 = "352";
                        String a30 = "354";
                        String a31 = "355";
                        String a32 = "357";
                        String a33 = "358";
                        String a34 = "360";
                        String a35 = "361";
                        String a36 = "365";
                        String a37 = "366";
                        if (a1.equals(String.valueOf(num.getText())))
                            img1.setVisibility(View.VISIBLE);
                        else
                            img1.setVisibility(View.INVISIBLE);
                        if (a2.equals(String.valueOf(num.getText())))
                            img2.setVisibility(View.VISIBLE);
                        else
                            img2.setVisibility(View.INVISIBLE);
                        if (a3.equals(String.valueOf(num.getText())))
                            img3.setVisibility(View.VISIBLE);
                        else
                            img3.setVisibility(View.INVISIBLE);
                        if (a4.equals(String.valueOf(num.getText())))
                            img4.setVisibility(View.VISIBLE);
                        else
                            img4.setVisibility(View.INVISIBLE);
                        if (a5.equals(String.valueOf(num.getText())))
                            img5.setVisibility(View.VISIBLE);
                        else
                            img5.setVisibility(View.INVISIBLE);
                        if (a6.equals(String.valueOf(num.getText())))
                            img6.setVisibility(View.VISIBLE);
                        else
                            img6.setVisibility(View.INVISIBLE);
                        if (a7.equals(String.valueOf(num.getText())))
                            img7.setVisibility(View.VISIBLE);
                        else
                            img7.setVisibility(View.INVISIBLE);
                        if (a8.equals(String.valueOf(num.getText())))
                            img8.setVisibility(View.VISIBLE);
                        else
                            img8.setVisibility(View.INVISIBLE);
                        if (a9.equals(String.valueOf(num.getText())))
                            img9.setVisibility(View.VISIBLE);
                        else
                            img9.setVisibility(View.INVISIBLE);
                        if (a10.equals(String.valueOf(num.getText())))
                            img10.setVisibility(View.VISIBLE);
                        else
                            img10.setVisibility(View.INVISIBLE);
                        if (a11.equals(String.valueOf(num.getText())))
                            img11.setVisibility(View.VISIBLE);
                        else
                            img11.setVisibility(View.INVISIBLE);
                        if (a12.equals(String.valueOf(num.getText())))
                            img12.setVisibility(View.VISIBLE);
                        else
                            img12.setVisibility(View.INVISIBLE);
                        if (a13.equals(String.valueOf(num.getText())))
                            img13.setVisibility(View.VISIBLE);
                        else
                            img13.setVisibility(View.INVISIBLE);
                        if (a14.equals(String.valueOf(num.getText())))
                            img14.setVisibility(View.VISIBLE);
                        else
                            img14.setVisibility(View.INVISIBLE);
                        if (a15.equals(String.valueOf(num.getText())))
                            img15.setVisibility(View.VISIBLE);
                        else
                            img15.setVisibility(View.INVISIBLE);
                        if (a16.equals(String.valueOf(num.getText())))
                            img16.setVisibility(View.VISIBLE);
                        else
                            img16.setVisibility(View.INVISIBLE);
                        if (a17.equals(String.valueOf(num.getText())))
                            img17.setVisibility(View.VISIBLE);
                        else
                            img17.setVisibility(View.INVISIBLE);
                        if (a18.equals(String.valueOf(num.getText())))
                            img18.setVisibility(View.VISIBLE);
                        else
                            img18.setVisibility(View.INVISIBLE);
                        if (a19.equals(String.valueOf(num.getText())))
                            img19.setVisibility(View.VISIBLE);
                        else
                            img19.setVisibility(View.INVISIBLE);
                        if (a20.equals(String.valueOf(num.getText())))
                            img20.setVisibility(View.VISIBLE);
                        else
                            img20.setVisibility(View.INVISIBLE);
                        if (a21.equals(String.valueOf(num.getText())))
                            img21.setVisibility(View.VISIBLE);
                        else
                            img21.setVisibility(View.INVISIBLE);
                        if (a22.equals(String.valueOf(num.getText())))
                            img22.setVisibility(View.VISIBLE);
                        else
                            img22.setVisibility(View.INVISIBLE);
                        if (a23.equals(String.valueOf(num.getText())))
                            img23.setVisibility(View.VISIBLE);
                        else
                            img23.setVisibility(View.INVISIBLE);
                        if (a24.equals(String.valueOf(num.getText())))
                            img24.setVisibility(View.VISIBLE);
                        else
                            img24.setVisibility(View.INVISIBLE);
                        if (a25.equals(String.valueOf(num.getText())))
                            img25.setVisibility(View.VISIBLE);
                        else
                            img25.setVisibility(View.INVISIBLE);
                        if (a26.equals(String.valueOf(num.getText())))
                            img26.setVisibility(View.VISIBLE);
                        else
                            img26.setVisibility(View.INVISIBLE);
                        if (a27.equals(String.valueOf(num.getText())))
                            img27.setVisibility(View.VISIBLE);
                        else
                            img27.setVisibility(View.INVISIBLE);
                        if (a28.equals(String.valueOf(num.getText())))
                            img28.setVisibility(View.VISIBLE);
                        else
                            img28.setVisibility(View.INVISIBLE);
                        if (a29.equals(String.valueOf(num.getText())))
                            img29.setVisibility(View.VISIBLE);
                        else
                            img29.setVisibility(View.INVISIBLE);
                        if (a30.equals(String.valueOf(num.getText())))
                            img30.setVisibility(View.VISIBLE);
                        else
                            img30.setVisibility(View.INVISIBLE);
                        if (a31.equals(String.valueOf(num.getText())))
                            img31.setVisibility(View.VISIBLE);
                        else
                            img31.setVisibility(View.INVISIBLE);
                        if (a32.equals(String.valueOf(num.getText())))
                            img32.setVisibility(View.VISIBLE);
                        else
                            img32.setVisibility(View.INVISIBLE);
                        if (a33.equals(String.valueOf(num.getText())))
                            img33.setVisibility(View.VISIBLE);
                        else
                            img33.setVisibility(View.INVISIBLE);
                        if (a34.equals(String.valueOf(num.getText())))
                            img34.setVisibility(View.VISIBLE);
                        else
                            img34.setVisibility(View.INVISIBLE);
                        if (a35.equals(String.valueOf(num.getText())))
                            img35.setVisibility(View.VISIBLE);
                        else
                            img35.setVisibility(View.INVISIBLE);
                        if (a36.equals(String.valueOf(num.getText())))
                            img36.setVisibility(View.VISIBLE);
                        else
                            img36.setVisibility(View.INVISIBLE);
                        if (a37.equals(String.valueOf(num.getText())))
                            img37.setVisibility(View.VISIBLE);
                        else
                            img37.setVisibility(View.INVISIBLE);
                    }
                }
        );
    }
}